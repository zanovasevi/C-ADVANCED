﻿using System;
using System.Collections.Generic;

namespace DefiningClasses
{
    public class Family
    {
        List<Person> people = new List<Person>();


        public void AddMember(Person member)
        {
            people.Add(member);
        }

        public Person GetOldestMember()
        {
            int maxAge = int.MinValue;
            string maxName = null;
            Person maxPerson = new Person();

            foreach(var person in people)
            {
                if(person.Age > maxAge)
                {
                    maxAge = person.Age;
                    maxName = person.Name;
                    maxPerson.Name = maxName;
                    maxPerson.Age = maxAge;
                }
            }

            return maxPerson;
        }

        public List<Person> GetPeopleOver30()
        {
            List<Person> listPeople = new List<Person>();

            foreach(var person in people)
            {
                if(person.Age > 30)
                {
                    listPeople.Add(person);
                }
            }

            return listPeople;
        }
    }
}
