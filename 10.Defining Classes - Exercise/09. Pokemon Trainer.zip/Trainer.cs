﻿using System;
using System.Collections.Generic;
namespace Pokemon_Trainer
{
    public class Trainer
    {

        public Trainer()
        {

        }

        public Trainer(string name)
        {
            Name = name;
            Badges = 0;
            Pokemon = new List<Pokemon>();
        }




        public string Name { get; set; }

        public int Badges { get; set; }

        public List<Pokemon> Pokemon { get; set; }
    }
}
