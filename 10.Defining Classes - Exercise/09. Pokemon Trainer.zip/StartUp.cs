﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Pokemon_Trainer
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Dictionary<string, Trainer> dict = new Dictionary<string, Trainer>();

            string input = Console.ReadLine();

            while(input != "Tournament")
            {
                string[] splitted = input.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                string trainerName = splitted[0];
                string pokemonName = splitted[1];
                string pokemonElement = splitted[2];
                int pokemonHealth = int.Parse(splitted[3]);

                Pokemon pokemon = new Pokemon(pokemonName, pokemonElement, pokemonHealth);
                Trainer trainer = new Trainer(trainerName);

                if(!dict.ContainsKey(trainerName))
                {
                    dict.Add(trainerName, new Trainer(trainerName));
                }

                dict[trainerName].Pokemon.Add(new Pokemon(pokemonName, pokemonElement, pokemonHealth));

                input = Console.ReadLine();
            }

            string command = Console.ReadLine();

            while(command != "End")
            {
                foreach(var trainer in dict)
                {
                    Trainer trainerToCheck = trainer.Value;
                    if (trainerToCheck.Pokemon.Any(p => p.Element == command))
                    {
                        trainerToCheck.Badges++;
                    }
                    else
                    {
                        for (int i = 0; i < trainerToCheck.Pokemon.Count; i++)
                        {
                            var pokemonToCheck = trainerToCheck.Pokemon[i];
                            if (pokemonToCheck.Health > 10)
                            {
                                pokemonToCheck.Health -= 10;
                            }
                            else
                            {
                                trainerToCheck.Pokemon.Remove(pokemonToCheck);
                                i--;
                            }
                        }
                    }
                }                    

                command = Console.ReadLine();
            }

            var sorted = dict.OrderByDescending(t => t.Value.Badges);

            foreach (var tr in sorted)
            {
                var trn = tr.Value;
                Console.WriteLine($"{trn.Name} {trn.Badges} {trn.Pokemon.Count}");
            }
        }
    }
}
