﻿using System;
namespace Speed_Racing
{
    public class Car
    {
        public Car()
        {

        }

        public Car(string model, double fuelAmount, double fuelConsumptionPerKm)
        {
            Model = model;
            FuelAmount = fuelAmount;
            FuelConsumptionPerKm = fuelConsumptionPerKm;
        }



        public string Model { get; set; }

        public double FuelAmount { get; set; }

        public double FuelConsumptionPerKm { get; set; }

        public double TravelledDistance { get; set; }



        public bool MoveCarOrNot(double distance, double fuelAmount,
            double fuelConsumptionPerKm)
        {
            double result = fuelAmount - (distance * fuelConsumptionPerKm);
            if(result >= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
