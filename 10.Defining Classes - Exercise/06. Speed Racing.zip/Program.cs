﻿using System;
using System.Collections.Generic;

namespace Speed_Racing
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Car> listCars = new List<Car>();

            int numCars = int.Parse(Console.ReadLine());

            for(int i = 0; i < numCars; i++)
            {
                string[] splitted = Console.ReadLine().Split(new string[] { " " },
                    StringSplitOptions.RemoveEmptyEntries);
                string model = splitted[0];
                double fuelAmount = double.Parse(splitted[1]);
                double fuelConsumptionPerKm = double.Parse(splitted[2]);

                Car car = new Car(model, fuelAmount, fuelConsumptionPerKm);

                listCars.Add(car);
            }

            string input = Console.ReadLine();

            while(input != "End")
            {
                string[] splitted = input.Split(new string[] { " "},
                    StringSplitOptions.RemoveEmptyEntries);
                string carModel = splitted[1];
                double distance = double.Parse(splitted[2]);

                
                foreach(var name in listCars)
                {
                    if(name.Model == carModel)
                    {
                        bool moveCarOrNot = name.MoveCarOrNot(distance, name.FuelAmount, name.FuelConsumptionPerKm);

                        if(moveCarOrNot)
                        {
                            name.FuelAmount -= (distance * name.FuelConsumptionPerKm);
                            name.TravelledDistance += distance;
                        }
                        else
                        {
                            Console.WriteLine($"Insufficient fuel for the drive");
                        }
                    }
                }
                
                input = Console.ReadLine();
            }

            foreach(var car in listCars)
            {
                Console.WriteLine($"{car.Model} {car.FuelAmount:F2} {car.TravelledDistance}");
            }
        }
    }
}
