﻿using System;
using System.Collections.Generic;

namespace DefiningClasses
{
    public class Family
    {
        public Family()
        {
            People = new List<Person>();
        }

        public List<Person> People { get; set; }



        public void AddMemeber(Person member)
        {
            People.Add(member);
        }



        public Person GetOldestMember()
        {
            Person person = null;
            var currentAge = int.MinValue;

            foreach (var currentPerson in People)
            {
                

                if(currentPerson.Age > currentAge)
                {
                    currentAge = currentPerson.Age;
                    person = currentPerson;
                }
            }

            return person;
        }
    }
}
