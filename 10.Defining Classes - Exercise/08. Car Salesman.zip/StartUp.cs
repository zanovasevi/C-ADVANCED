﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Car_Salesman
{
    class StartUp
    {
        static void Main(string[] args)
        {
            List<Engine> listEngines = new List<Engine>();

            int numEngines = int.Parse(Console.ReadLine());

            for (int i = 0; i < numEngines; i++)
            {
                string[] input = Console.ReadLine().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                string model = input[0];
                int power = int.Parse(input[1]);

                Engine engine = new Engine(model, power);

                if (input.Length == 3)
                {
                    string displ = input[2];
                    string efficiency;
                    if (char.IsDigit(displ[0]))
                    {
                        int displacement = int.Parse(displ);
                        engine.Displacement = displacement;
                    }
                    else
                    {
                        efficiency = input[2];
                        engine.Efficiency = efficiency;
                    }

                }
                if (input.Length == 4)
                {
                    int displacement = int.Parse(input[2]);
                    string efficiency = input[3];
                    engine.Displacement = displacement;
                    engine.Efficiency = efficiency;

                }

                listEngines.Add(engine);
            }

            List<Car> listCars = new List<Car>();

            int numCars = int.Parse(Console.ReadLine());

            for (int i = 0; i < numCars; i++)
            {
                string[] input = Console.ReadLine().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                string model = input[0];
                string engineModel = input[1];
                int weight = 0;

                Engine engine = listEngines.FirstOrDefault(x => x.Model == engineModel);

                Car car = new Car(model, engine);

                if (input.Length == 3)
                {
                    string symbol = input[2];
                    if (char.IsDigit(symbol[0]))
                    {
                        weight = int.Parse(input[2]);
                        car.Weight = weight;
                    }
                    else
                    {
                        car.Color = input[2];
                    }
                }
                if (input.Length == 4)
                {
                    car.Weight = int.Parse(input[2]);
                    car.Color = input[3];
                }

                listCars.Add(car);
            }

            foreach (var car in listCars)
            {
                

                Console.WriteLine($"{car.Model}:");
                Console.WriteLine($"  {car.Engine.Model}:");
                Console.WriteLine($"    Power: {car.Engine.Power}");
                if(car.Engine.Displacement == 0)
                {
                    string str = car.Engine.Displacement.ToString();
                    str = "n/a";
                    Console.WriteLine($"    Displacement: {str}");
                }
                else
                {
                    Console.WriteLine($"    Displacement: {car.Engine.Displacement}");
                }
                
                Console.WriteLine($"    Efficiency: {car.Engine.Efficiency}");
                if (car.Weight == 0)
                {
                    string str = car.Weight.ToString();
                    str = "n/a";
                    Console.WriteLine($"  Weight: {str}");
                }
                else
                {
                    Console.WriteLine($"  Weight: {car.Weight}");
                }
                Console.WriteLine($"  Color: {car.Color}");
            }
        }
    }
}
