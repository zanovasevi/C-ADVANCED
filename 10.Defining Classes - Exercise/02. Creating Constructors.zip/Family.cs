﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class Family
    {
        public Family()
        {
            People = new List<Person>();
        }

        public List<Person> People { get; set; }



        public void AddMemeber(Person member)
        {
            People.Add(member);
        }



        public Person GetOldestMember()
        {
            Person person = null;
            var currentAge = int.MinValue;

            foreach (var currentPerson in People)
            {
                

                if(currentPerson.Age > currentAge)
                {
                    currentAge = currentPerson.Age;
                    person = currentPerson;
                }
            }

            return person;
        }

        public Person[] GetPeople()
        {
            var people = People.Where(x => x.Age > 30)
                .OrderBy(x => x.Name).ToArray();

            return people;
        }
    }
}
