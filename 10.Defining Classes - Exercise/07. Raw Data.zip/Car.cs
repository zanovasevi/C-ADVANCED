﻿using System;
namespace Raw_Data
{
    public class Car
    {


        public Car(string model, Engine engineInfo, Cargo cargoInfo, Tire tireInfo)
        {
            Model = model;
            EngineInfo = engineInfo;
            CargoInfo = cargoInfo;
            TireInfo = tireInfo;
        }


        public string Model { get; set; }

        public Engine EngineInfo { get; set; }

        public Cargo CargoInfo { get; set; }

        public Tire TireInfo { get; set; }


    }
}
