﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Raw_Data
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<Car> listCars = new List<Car>();

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] input = Console.ReadLine().Split();

                string model = input[0];

                int engineSpeed = int.Parse(input[1]);
                int enginePower = int.Parse(input[2]);

                int cargoWeight = int.Parse(input[3]);
                string cargoType = input[4];

                double tire1Pressure = double.Parse(input[5]);
                int tire1Age = int.Parse(input[6]);
                double tire2Pressure = double.Parse(input[7]);
                int tire2Age = int.Parse(input[8]);
                double tire3Pressure = double.Parse(input[9]);
                int tire3Age = int.Parse(input[10]);
                double tire4Pressure = double.Parse(input[11]);
                int tire4Age = int.Parse(input[12]);

                Engine engine = new Engine(engineSpeed, enginePower);
                Cargo cargo = new Cargo(cargoWeight, cargoType);
                Tire tire = new Tire(tire1Pressure, tire1Age, tire2Pressure, tire2Age, tire3Pressure, tire3Age, tire4Pressure, tire4Age);

                Car car = new Car(model, engine, cargo, tire);

                listCars.Add(car);

            }

            string command = Console.ReadLine();

            if(command == "fragile")
            {
                foreach(var car in listCars)
                {
                    bool pressureOne = car.TireInfo.Tire1Pressure < 1;
                    bool pressureTwo = car.TireInfo.Tire2Pressure < 1;
                    bool pressureThree = car.TireInfo.Tire3Pressure < 1;
                    bool pressureFour = car.TireInfo.Tire4Pressure < 1;


                    if (car.CargoInfo.CargoType == "fragile" && (pressureOne || pressureTwo
                        || pressureThree || pressureFour))
                    {
                        Console.WriteLine($"{car.Model}");
                    }
                }
            }
            else if(command == "flamable")
            {
                foreach(var car in listCars)
                {
                    if(car.CargoInfo.CargoType == "flamable" &&
                        car.EngineInfo.EnginePower > 250)
                    {
                        Console.WriteLine($"{car.Model}");
                    }
                }
            }
        }
    }
}
