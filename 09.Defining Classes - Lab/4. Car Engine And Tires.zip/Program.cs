﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car defaultCar = new Car();

            

            Car thirdCar = new Car("HYUNDAI", "i20", 2016);

            

            //car.Make = "VW";
            //car.Model = "X3";
            //car.Year = 1990;

            
            //thirdCar.FuelQuantity = 200;
            //thirdCar.FuelConsumption = 200;
            //thirdCar.Drive(2000);
            //Console.WriteLine(thirdCar.WhoAmI());
        }
    }
}
